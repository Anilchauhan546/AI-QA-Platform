from fastapi import FastAPI
from fastapi.openapi.utils import get_openapi

from .database import engine
from . import models
from .Routes import auth, projects, testcases, defects

# ─── Create Tables ────────────────────────────────────────────────────────────
models.Base.metadata.create_all(bind=engine)

# ─── App ──────────────────────────────────────────────────────────────────────
app = FastAPI(title="AI QA Platform")

# ─── Routers ──────────────────────────────────────────────────────────────────
app.include_router(auth.router, prefix="/auth", tags=["Authentication"])
app.include_router(projects.router)
app.include_router(testcases.router)
app.include_router(defects.router)


# ─── Home ─────────────────────────────────────────────────────────────────────
@app.get("/")
def home():
    return {"msg": "AI QA Platform Running"}


# ─── Custom OpenAPI — adds 🔒 Authorize button in Swagger UI ──────────────────
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema

    openapi_schema = get_openapi(
        title="AI QA Platform",
        version="1.0.0",
        description="API with JWT Bearer Authentication",
        routes=app.routes,
    )

    # Adds the Authorize 🔒 button
    openapi_schema["components"]["securitySchemes"] = {
        "BearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
        }
    }

    # Apply Bearer auth to all routes except public ones
    public_routes = ["/auth/register", "/auth/login", "/"]
    for path, methods in openapi_schema["paths"].items():
        if path not in public_routes:
            for method in methods.values():
                method["security"] = [{"BearerAuth": []}]

    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi