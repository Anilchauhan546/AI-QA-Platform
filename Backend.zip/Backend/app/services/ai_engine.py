def analyze_defect(text: str):

    if "error" in text.lower():
        severity = "High"
    elif "fail" in text.lower():
        severity = "Medium"
    else:
        severity = "Low"

    return {
        "analysis": "AI analyzed the defect",
        "predicted_severity": severity
    }
